'use strict';

/**
 * @ngdoc overview
 * @name sancorsaludApp
 * @description
 * # sancorsaludApp
 *
 * Main module of the application.
 */
angular
  .module('sancorsaludApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
  .config(['$routeProvider', '$locationProvider', 'UserAuthProvider', '$httpProvider', function ($routeProvider, $locationProvider, UserAuthProvider, $httpProvider) {


    $routeProvider

      .when('/', {
        templateUrl: 'views/login.html',
        controller: 'LoginController',
        controllerAs: 'login',
        resolve: {
          loggedin: function (UserAuth, $q, $timeout, $location, $rootScope) {
            var deferred = $q.defer();
            return UserAuth.isLoggedIn(function (response) {
              deferred.reject();
              $location.url(Config.publicPages.assignedToPromoter);
            }, function (response) {
              deferred.resolve();
            });
          }
        }
      })
      .when(Config.publicPages.assignedToPromoter, {
        templateUrl: 'views/assignedToPromoter.html',
        controller: 'AssignedToPromoterController',
        controllerAs: 'AssignedToPromoterController',
        resolve: {
          loggedin: function (UserAuth, $q, $timeout, $location, $rootScope) {
            var deferred = $q.defer();
            return UserAuth.isLoggedIn(function (response) {
              deferred.resolve();
            }, function (response) {
              deferred.reject();
              $location.url('/');
            });
          }
        }
      })
      .when(Config.publicPages.promoterList, {
        templateUrl: 'views/promoterList.html',
        controller: 'PromoterListController',
        controllerAs: 'PromoterListController',
        resolve: {
          loggedin: function (UserAuth, $q, $timeout, $location, $rootScope) {
            var deferred = $q.defer();
            return UserAuth.isLoggedIn(function (response) {
              deferred.resolve();
            }, function (response) {
              deferred.reject();
              $location.url('/');
            });
          }
        }
      })
      .when(Config.publicPages.toBeAssigned, {
        templateUrl: 'views/toBeAssigned.html',
        controller: 'TobeassignedcontrollerCtrl',
        controllerAs: 'TobeassignedcontrollerCtrl',
        resolve: {
          loggedin: function (UserAuth, $q, $timeout, $location, $rootScope) {
            var deferred = $q.defer();
            return UserAuth.isLoggedIn(function (response) {
              deferred.resolve();
            }, function (response) {
              deferred.reject();
              $location.url('/');
            });
          }
        }
      })
      .when(Config.publicPages.agenda, {
        templateUrl: 'views/agenda.html',
        controller: 'AgendaCtrl',
        resolve: {
          loggedin: function (UserAuth, $q, $timeout, $location, $rootScope) {
            var deferred = $q.defer();
            return UserAuth.isLoggedIn(function (response) {
              deferred.resolve();
            }, function (response) {
              deferred.reject();
              $location.url('/');
            });
          }
        }
      })
      .when(Config.publicPages.newAssociatedPotential, {
        templateUrl: 'views/newAssociatedPotential.html',
        controller: 'NewAssociatedPotentialController',
        resolve: {
          loggedin: function (UserAuth, $q, $timeout, $location, $rootScope) {
            var deferred = $q.defer();
            return UserAuth.isLoggedIn(function (response) {
              deferred.resolve();
            }, function (response) {
              deferred.reject();
              $location.url('/');
            });
          }
        }
      })
      .otherwise({
        redirectTo: '/'
      });
    $locationProvider.hashPrefix('');


    //check if i am logged in
    if (localStorage.getItem("token") != null) {
      $httpProvider.defaults.headers.common['token'] = localStorage.getItem("token");
    }

    // allow cross-domain
    $httpProvider.defaults.withCredentials = false;
    delete $httpProvider.defaults.headers.common['X-Requested-With'];

    $httpProvider.defaults.headers.post['Accept'] = 'application/json, text/javascript';
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
    $httpProvider.defaults.headers.common['Accept'] = 'application/json, text/javascript';
    $httpProvider.defaults.headers.common['Content-Type'] = 'application/json; charset=utf-8';
    $httpProvider.defaults.useXDomain = true;

  }]);
